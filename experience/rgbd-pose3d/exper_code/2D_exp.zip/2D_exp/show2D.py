import numpy as np
import scipy.misc
import cv2
def _preproc_color(image):
    """ Preprocessing the color image"""
    output_shape = np.array([376.0, 656.0], np.float32)

    # reshape by trafo
    ratio = np.min(output_shape / np.array(image.shape[:2], dtype=np.float32))
    M = np.array([[ratio, 0.0, 0.0], [0.0, ratio, 0.0]])
    image_s = cv2.warpAffine(image, M, (output_shape[1], output_shape[0]), flags=cv2.INTER_AREA)

    # subtract mean and rgb -> bgr
    image = image_s[:, :, 0:3].astype('float32')
    image = image[:, :, ::-1]
    image = image / 256.0 - 0.5
    image = np.expand_dims(image, 0)
    return image, image_s, ratio
def _show_openpose_det(image_s, person_det, block=True):
        """ Shows the detections of openpose in the color image. """
        import matplotlib.pyplot as plt
        from utils.DrawUtil import draw_person_limbs_2d_coco
        fig = plt.figure()
        ax1 = fig.add_subplot(111)
        ax1.imshow(image_s)
        fmt_list = ['ro', 'go', 'co', 'mo']
        for anno, fmt in zip(person_det.values(), fmt_list):
            coords = np.zeros((18, 2))
            vis = np.zeros((18, ))
            for i, kp in enumerate(anno['kp']):
                if (kp is not None) and (kp[2] > 0.1):
                    # ax1.plot(kp[0], kp[1], fmt)
                    coords[i, :] = np.array([kp[0], kp[1]])
                    vis[i] = 1.0

            draw_person_limbs_2d_coco(ax1, coords, vis, color='sides', order='uv')
        # plt.show(block=block)
        plt.savefig('RGB.png')
if __name__ == "__main__":
    images='./RGB140.png'
    color = scipy.misc.imread(images)  # color image
    color = scipy.misc.imresize(color, (1080, 1920))
    image_proc, image_s, scale_ratio =_preproc_color(color)
    person_det={'person0': {'kp': [
        [376.       ,  32.       ,   0.8929911],#0.鼻子
        [360.       ,  88.       ,   0.8367073],#1.脖子
        [328.        ,  80.        ,   0.63945055],#2.右肩
        [288.      , 120.      ,   0.805474],#3.右肘
        [256.        ,  88.        ,   0.72609437],#4.右腕
        [392.        ,  88.        ,   0.76638436],#5.左肩
        [408.       , 144.       ,   0.8374882],#6.左肘
        [456.       , 144.       ,   0.7570134],#7.左腕
        [328.        , 200.        ,   0.49084562],#8.右臀
        [344.       , 296.       ,   0.5863148],#右膝
        [344, 368, 0.19652022],#右踝
        [384.        , 200.        ,   0.40056953],#左臀
        [408.        , 272.        ,   0.67569005],#左膝
        [416, 336, 0.40510252],#左踝
        [360.       ,  24.       ,   0.7857645],#右眼
        [384.       ,  24.       ,   0.9599892],#左眼
        [352.        ,  40.        ,   0.89546907],#右耳
        [392.      ,  40.      ,   0.860474]#左耳
        ],
         'conf': 0.7197682335580649}}
    _show_openpose_det(image_s,person_det)
    print('done')
    pass