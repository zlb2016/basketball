#!/usr/bin/env python
# -*- coding:utf-8 -*-
import scipy.misc
import numpy as np
import matplotlib.pyplot as plt

from PoseNet2D import *
from utils.Camera import *
import os
import json

# VALUES YOU MIGHT WANT TO CHANGE
OPE_DEPTH = 1  # in [1, 5]; Number of stages for the 2D network. Smaller number makes the network faster but less accurate
VPN_TYPE = 'fast'  # in {'fast', 'default'}; which 3D architecture to use
CONF_THRESH = 0.01  # threshold for a keypoint to be considered detected (for visualization)
GPU_ID = 0  # id of gpu device
GPU_MEMORY = None  # in [0.0, 1.0 - eps]; percentage of gpu memory that should be used; None for no limit
# NO CHANGES BEYOND THIS LINE
def dealpic(color_pic,depth_pic):
    """  APPROX. RUNTIMES (measured on a GTX 1080 Ti, frame with 4 people)
    VPN=fast, OPE=1: 0.51sec = 1.96 Hz
    VPN=fast, OPE=5: 0.56sec = 1.79 Hz
    VPN=default, OPE=1: 0.59sec = 1.70 Hz
    VPN=default, OPE=5: 0.64sec = 1.57 Hz

    APPROX. RUNTIMES (measured on a GTX 970, frame with 4 people)
    VPN=fast, OPE=1: 1.20 = 0.84 Hz
    VPN=fast, OPE=5: 1.30 sec = 0.77 Hz
    VPN=default, OPE=1: 1.41sec = 0.71 Hz
    VPN=default, OPE=5: 1.54sec = 0.65 Hz

    NOTE: Runtime scales with the number of people in the scene.
    """
    # load data
    color = scipy.misc.imread('./pictures/63_rgb/frames_'+color_pic+'.png')  # color image
    color = scipy.misc.imresize(color, (1080, 1920))
    depth_w = scipy.misc.imread('./pictures/63_depth/MDepth-'+depth_pic+'.png').astype('float32')  # depth map warped into the color frame

    # intrinsic calibration data
    ratio = np.array([1920.0/512.0, 1080.0/424.0])
    K = np.array([[3.7132019636619111e+02 * ratio[0], 0.0, 2.5185416982679811e+02 * ratio[0]],
                   [0.0, 3.7095047063504268e+02 * ratio[1], 2.1463524817996452e+02 * ratio[1]],
                   [0.0, 0.0, 1.0]])
    cam = Camera(K)

    # create algorithm
    poseNet = PoseNet2D(ope_depth=OPE_DEPTH, vpn_type=VPN_TYPE,
                        gpu_id=GPU_ID, gpu_memory_limit=GPU_MEMORY, K=K)

    # loop
    mask = np.logical_not(depth_w == 0.0)#逻辑非

    # run algorithm
    person_det, keypoint_det_fs = poseNet.detect(color, depth_w, mask)

    print('person_det',person_det)
    # # visualize##视频帧的数目(需要在存储姿态json文件时将多个帧的姿态存放在同一json文件中)
    # json_results = []
    # dic = {}
    # import matplotlib.pyplot as plt
    # fig = plt.figure()
    # ax = fig.add_subplot(111)
    # ax.imshow(color)
    # with open("./ntu_3d.json", "a") as f:#3D坐标
    #   for i in range(coords_pred.shape[0]):
    #       coord2d = cam.project(coords_pred[i, :, :])
    #       vis = det_conf[i, :] > CONF_THRESH
    #       json_results.append(coord2d[vis])
    #       dic['person_num'] = i
    #       dic['person'] = coords_pred[i, :, :].tolist()#3D坐标
    #       print('json_results', json_results)
    #       dicJson = json.dumps(dic)
    #       f.write(dicJson+'\n')
    #       ax.plot(coord2d[vis, 0], coord2d[vis, 1], 'ro')
    #   plt.savefig('./res/res_'+color_pic+'.png')
    #   pass
    # #plt.show()

if __name__ == '__main__':
    rgb_list=''
    depth_list=''
    dealpic(rgb_list,depth_list)
    pass
